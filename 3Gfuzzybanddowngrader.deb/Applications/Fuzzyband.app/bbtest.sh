#!/bin/bash
# RUN QUERYVERSION FOR BASEBAND AND BOOTLOADER VERSIONS
cd $(dirname $0)

BBUPDATER="BB${1}0"

BASEBAND=`grep 'Firmware Version' /tmp/out.log`
# echo $BL
# echo $BASEBAND

BASEBAND=`echo ${BASEBAND} | sed 's/Firmware Version: //'`

# echo $BASEBAND
# PATCH ORIGINAL BASED ON VERSION
rm -rf /tmp/patched.fls
rm -rf /tmp/update.error

cp ICE2_02.28.00.fls /tmp/patched.fls

# 
echo -en "\x06\x00\x00\xea\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf0\xff\x09\x00\xf4\xff\x09\x00\xfc\x3f\xff\xff\x18\x00\x9f\xe5\x1f\x10\xa0\xe3\x00\x10\xc0\xe5\x10\x20\x9f\xe5\x00\x00\x92\xe5\x0c\x20\x9f\xe5\x00\x10\x92\xe5\x17\x04\x00\xea\x2c\x02\x08\x00\xf0\xff\x09\x00\xf4\xff\x09\x00" | dd of=/tmp/patched.fls conv=notrunc bs=6294088 seek=1 1> /dev/null 2> /dev/null

if [ -f "${BASEBAND}.cert" ]
then
	dd if=${BASEBAND}.cert  bs=1 skip=0 count=128 of=/tmp/patched.fls conv=notrunc seek=6350592 &> /dev/null
else
	echo Baseband not supported yet [${BASEBAND}]
	exit 1
fi

# downgrade baseband

launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist
./${BBUPDATER} update -f /tmp/patched.fls -e ICE2_02.28.00.eep 1> /dev/null 2> /tmp/update.error
launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist

if [ -f /tmp/update.error ]
then
	ERRORTEXT=`cat /tmp/update.error`
	if [ -n "${ERRORTEXT}" ]
	then
		echo ${ERRORTEXT}
		exit 1
	else
		echo I HAZ DOWNGRADE!
		exit 0
	fi
else
	echo I HAZ DOWNGRADE!
	exit 0
fi
