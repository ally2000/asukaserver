#!/bin/bash
# RUN QUERYVERSION FOR BASEBAND AND BOOTLOADER VERSIONS

BBUPDATER="BB${1}0"

cd $(dirname $0)
launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist
./${BBUPDATER} queryversion 1> /tmp/out.log 2> /dev/null
launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist

BLTEMP=$(grep 'Boot Loader Version' /tmp/out.log | sed 's/Boot Loader Version: //')
BL=$(echo $BLTEMP | cut -d'_' -f3)
BL2=$(echo $BLTEMP | cut -d'_' -f4)
BASEBAND=`grep 'Firmware Version' /tmp/out.log | sed 's/Firmware Version: //'`

echo -n "$BL $BL2 $BASEBAND"
if [[ "$BL" == "05.08" ]]; then
	exit 0
else
	exit 1
fi
