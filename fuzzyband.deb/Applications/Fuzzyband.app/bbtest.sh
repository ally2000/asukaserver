#!/bin/bash
# UPGRADE / DOWNGRADE BASEBAND BASED ON VERSION
cd $(dirname $0)

BBUPDATER="BB${1}0"

rm -rf /tmp/fuzzy*

BASEBAND="${2}"		#BASEBAND FULL
BBINT=$3 		#INT VALUE OF BASEBAND FOR COMPARISON

#LOOK AT VERSION AND DECIDE IF WE'RE UPGRADING OR DOWNGRADING
if [[ $BBINT > 51304 ]]; then
 	# DOWNGRADING BASEBAND TO 5.13.04 THE CURRENT UNLOCKABLE BASEBAND
	# REQUIRES PATCHING WITH APPROPRIATE CERT

	rm -rf /tmp/fuzzy_patched.fls

	cp ICE2_05.13.04.fls /tmp/fuzzy_patched.fls #copy original to /tmp for patching

	# PATCH THE BOOTLOADER WITH 76BYTE EXPLOIT (CREDIT: GEOHOT IN 2.28.00)
	echo -en "\x06\x00\x00\xea\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xf0\xff\x09\x00\xf4\xff\x09\x00\xfc\x3f\xff\xff\x18\x00\x9f\xe5\x1f\x10\xa0\xe3\x00\x10\xc0\xe5\x10\x20\x9f\xe5\x00\x00\x92\xe5\x0c\x20\x9f\xe5\x00\x10\x92\xe5\x17\x04\x00\xea\x2c\x02\x08\x00\xf0\xff\x09\x00\xf4\xff\x09\x00" | dd of=/tmp/fuzzy_patched.fls conv=notrunc bs=6661420 seek=1 1> /dev/null 2> /dev/null

	# CHECK FOR CERT FILE IF EXISTS PATCH WITH RUN CERT FROM FILE
	if [ -f "${BASEBAND}.cert" ]
	then
		dd if=${BASEBAND}.cert  bs=1 skip=0 count=128 of=/tmp/fuzzy_patched.fls conv=notrunc seek=6717924 &> /dev/null
	else
        	echo Baseband not supported yet [${BASEBAND}]
        	exit 1
	fi
	
	# FLASH PATCHED BASEBAND
	# 4.0GM INTRODUCES RACE CONDITION, STOPPING ALL COMMCENTER DAEMONS SEEMS TO SOLVE THE PROBLEM [FINGERS CROSSED]
	
	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log

	./${BBUPDATER} update -f /tmp/fuzzy_patched.fls -e ICE2_05.13.04.eep 1> /dev/null 2> /tmp/fuzzy_update_err.log

	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log

	if [ -f /tmp/fuzzy_update_err.log ]
	then
        	ERRORTEXT=`cat /tmp/fuzzy_update_log.log`
        	if [ -n "${ERRORTEXT}" ]
        	then
                	echo ${ERRORTEXT}
                	exit 1
        	else
                	echo I HAZ DOWNGRADE!
                	exit 0
       	 	fi
	else
        	echo I HAZ DOWNGRADE!
        	exit 0
	fi


else
	# UPGRADE TO 5.13.04 THE CURRENT UNLOCKABLE BASEBAND
	# UPGRADING REQUIRES NO PATCHING, JUST FLASH FLS+EEP

	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
	launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log

	./${BBUPDATER} update -f ICE2_05.13.04.fls -e ICE2_05.13.04.eep 1> /dev/null 2> /tmp/fuzzy_update_err.log

	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
	launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log


	if [ -f /tmp/fuzzy_update_err.log ]
	then
        	ERRORTEXT=`cat /tmp/fuzzy_update_err.log`
        	if [ -n "${ERRORTEXT}" ]
        	then
                	echo ${ERRORTEXT}
                	exit 1
        	else
                	echo I HAZ UPGRADE!
                	exit 0
        	fi
	else
        	echo I HAZ UPGRADE!
        	exit 0
	fi

fi


