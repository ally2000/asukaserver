#!/bin/bash
# RUN QUERYVERSION FOR BASEBAND AND BOOTLOADER VERSIONS

rm -rf /tmp/fuzzy*

cd $(dirname $0)

BBUPDEX=BB${1}0

# 4.0GM INTRODUCES A RACE CONDITION, UNLOADING ALL COMMCENTER DAEMONS SEEMS TO FIX
# WE'LL ROLL WITH IT AND SEE HOW IT WORKS OUT

launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log


./${BBUPDEX} queryversion 1> /tmp/fuzzyout.log 2> /tmp/fuzzyerr.log

launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist &> /tmp/wtf.log
launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterRootHelper.plist &> /tmp/wtf.log
launchctl load /System/Library/LaunchDaemons/com.apple.CommCenterMobileHelper.plist &> /tmp/wtf.log


BLTEMP=$(grep 'BOOTLOADER_VERSION:' /tmp/fuzzyout.log | sed 's/BOOTLOADER_VERSION://')
if [[ "$BLTEMP" == "" ]]; then
	BLTEMP=$(grep 'Boot Loader Version:' /tmp/fuzzyout.log | sed 's/Boot Loader Version://')
	BL=$(echo $BLTEMP | cut -d'_' -f3 | sed 's/\"//g')
	BL2=$(echo $BLTEMP | cut -d'_' -f4 | sed 's/\"//g')
else
	BL=$(echo $BLTEMP | cut -d'_' -f1 | sed 's/\"//g')
	BL2=$(echo $BLTEMP | cut -d'_' -f2 | sed 's/\"//g' | cut -d',' -f1)
fi
BASEBAND=`grep 'ICE2_MODEM_' /tmp/fuzzyout.log | sed 's/ICE2_MODEM_//' | cut -d'"' -f2`
if [[ "$BASEBAND" == "" ]]; then
	BASEBAND=`grep 'Firmware Version:' /tmp/fuzzyout.log | sed 's/Firmware Version://' | cut -d' ' -f2 | sed 's/ICE2-//'`
fi
BASEBAND=$(echo ICE2-$BASEBAND)


echo -n "$BL $BL2 $BASEBAND"
if [[ "$BL" == "05.08" ]]; then
	exit 0
else
	exit 1
fi
